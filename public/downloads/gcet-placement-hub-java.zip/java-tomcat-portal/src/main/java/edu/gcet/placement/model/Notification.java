package edu.gcet.placement.model;

import java.sql.Timestamp;

public class Notification implements Identifiable {
    private int notificationId;
    private int userId;
    private String title;
    private String message;
    private boolean read;
    private Timestamp createdAt;

    @Override public int getId() { return notificationId; }
    @Override public void setId(int id) { this.notificationId = id; }

    public int getNotificationId() { return notificationId; }
    public void setNotificationId(int notificationId) { this.notificationId = notificationId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public boolean isRead() { return read; }
    public void setRead(boolean read) { this.read = read; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
